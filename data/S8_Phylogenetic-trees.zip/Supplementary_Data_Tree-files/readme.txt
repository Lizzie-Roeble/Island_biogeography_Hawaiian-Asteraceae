README: Supplementary Data – Phylogenetic Trees

This archive contains 23 phylogenetic trees. 

# Previously Published trees
3 of the trees are previously published phylogenies by: 
- Landis et al. 2018
- Knope et al. 2020
- Keeley et al. 2021 
(all cited in the main reference list)

# New trees
The other 20 trees are the phylogenetic trees that were newly generated for this study. 
Each tree of the 20 trees corresponds to an analysis described in the manuscript.

# File naming Convention

Dataset< Asteraceae-wide | Island-mainland | Gnaphalieae-tribe >
_Paralogy-resolution< Hybpiper-default | Paragone-MO | Paragone-RT | Paralog-free | Paralogs >
_Methods< MSC | ML-dated >

# Definitions

## Dataset definitions

Asteraceae-wide: to improve sampling and divergence time estimation using 441 samples from across the family and Angio353 loci
Island-mainland: to resolve relationships between Mascarene and mainland taxa; 254 samples, Angio353+Comp1061 loci
Gnaphalieae-tribe: to test relationships among the island Gnaphalieae species with 267 samples and Comp1061 loci

## Paralogy resolution methods

HybPiper-default = HybPiper ortholog selection (default).
Paragone-MO = Paragone “Monophyletic Outgroups” resolution.
Paragone-RT = Paragone “Rooted subTrees” resolution.
Paralog-free = filtered dataset removing loci with paralogs warnings.
Paralogs = dataset retaining paralogous loci.

## Tree building methods

MSC = Multispecies coalescent (ASTRAL).
ML-dated = Maximum likelihood phylogeny with fossil calibrations.

# File list

**Asteraceae-wide dataset**

Asteraceae-wide_Hybpiper-default_MSC.tre
Asteraceae-wide_Paralog-free_MSC.tre
Asteraceae-wide_Paragone-MO_MSC.tre
Asteraceae-wide_Paragone-RT_MSC.tre
Asteraceae-wide_Paralogs_MSC.tre

Asteraceae-wide_Hybpiper-default_ML-dated_bootstrap.tre
Asteraceae-wide_Paragone-MO_ML-dated_bootstrap.tre
Asteraceae-wide_Paralog-free_ML-dated_bootstrap.tre

**Island-mainland dataset**

Island-mainland_Hybpiper-default_MSC.tre
Island-mainland_Paralog-free_MSC.tre
Island-mainland_Paragone-MO_MSC.tre
Island-mainland_Paragone-RT_MSC.tre
Island-mainland_Paralogs_MSC.tre

Island-mainland_Hybpiper-default_ML-dated_bootstrap.tre
Island-mainland_Paragone-MO_ML-dated_bootstrap.tre
Island-mainland_Paralog-free_ML-dated_bootstrap.tre

**Gnaphalieae-tribe dataset**

Gnaphalieae-tribe_Hybpiper-default_MSC.tre
Gnaphalieae-tribe_Paragone-MO_MSC.tre
Gnaphalieae-tribe_Paralog-free_MSC.tre
Gnaphalieae-tribe_Paralogs_MSC.tre
